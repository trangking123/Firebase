// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyC_CZo7IvdrIQSHF1aITryUbgUwe_B2ias",
  authDomain: "databasecovid-8fac4.firebaseapp.com",
  projectId: "databasecovid-8fac4",
  storageBucket: "databasecovid-8fac4.appspot.com",
  messagingSenderId: "1097931104574",
  appId: "1:1097931104574:web:de2009df8265c38a874c6f",
  measurementId: "G-JKQ5CFCQEP",
});

const db = getFirestore(firebaseApp);
export default db;
